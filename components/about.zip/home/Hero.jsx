import Slider from '../Slider';

const Hero = () => {
  return (
    <>
      <Slider />
    </>
  );
};

export default Hero;
